if(!("ggplot2" %in% installed.packages()[,"Package"])){
    install.packages("ggplot2")
}
if(!("shiny" %in% installed.packages()[,"Package"])){
    install.packages("shiny")
}
if(!("DT" %in% installed.packages()[,"Package"])){
    install.packages("DT")
}
if(!("reshape2" %in% installed.packages()[,"Package"])){
    install.packages("reshape2")
}
if(!("plotly" %in% installed.packages()[,"Package"])){
    install.packages("plotly")
}
if(!("dplyr" %in% installed.packages()[,"Package"])){
    install.packages("dplyr")
}
if(!("shinythemes" %in% installed.packages()[,"Package"])){
    install.packages("shinythemes")
}
if(!("devtools" %in% installed.packages()[,"Package"])){
    install.packages("devtools")
}
if(!("backports" %in% installed.packages()[,"Package"])){
    install.packages("backports")
}
if(!("ggstat" %in% installed.packages()[,"Package"])){
    devtools::install_github("hadley/ggstat")
}
if(!("hypeR" %in% installed.packages()[,"Package"])){
    install.packages("rlang")
    devtools::install_github("montilab/hypeR")
}

library(hypeR) # make sure hypeR installs properly (test it)
library(ggstat) # install from https://github.com/hadley/ggstat
library(shiny)
library(plotly)
library(dplyr)
library(shinythemes)
library(DT)
library(reshape2)
library(ggplot2)

# Main results file
all_res <- readRDS("all.raw_expression.RDS")
all_res <- all_res %>% filter(Dataset %in% c("mRNA", "miRNA"))
all_res$Dataset <- factor(all_res$Dataset)
colnames(all_res) <- gsub("hsapiens_homolog_","hsa.h_",colnames(all_res))

# set these variables to numeric
pval.cols <- grep("padj",colnames(all_res))
all_res[,pval.cols] <- lapply(all_res[,pval.cols],as.numeric)

all_res <- all_res[order(all_res$LRT_padj),]

# Create a second DF for -log10(p) filtering
all_res2 <- all_res
all_res2[,pval.cols][is.na(all_res2[,pval.cols])] <- 1
all_res2[,pval.cols] <- lapply(all_res2[,pval.cols], function(x) {-log10(x)})
colnames(all_res2)[pval.cols] <- paste0("mlog10",colnames(all_res2)[pval.cols])

# L2FC filtering
L2FC.cols <- grep("L2FC",colnames(all_res2))
all_res2[,L2FC.cols][is.na(all_res2[,L2FC.cols])] <- 0

# round values
all_res[,c(pval.cols,L2FC.cols)] <- apply(all_res[,c(pval.cols,L2FC.cols)],2,function(x) {formatC(x, format = "e", digits = 2)})
    
# Collect numeric variables to be shown as histograms in the crossfilter
d <- all_res2 %>% dplyr::select(pval.cols, L2FC.cols)

# Pathways gene sets
genesets <- readRDS("genesets.RDS")
dbs <- c("C1", "C2.CP.BIOCARTA", "C2.CP.KEGG", "C2.CP.REACTOME", "C3.MIR", "C3.TFT", "C5.BP", "C5.CC", "C5.MF")


######################################################## UI ################################################################
ui <- navbarPage(
    theme = shinytheme("flatly"),
    # shinythemes::themeSelector(),
    title = "Dog AF data",
    
    ########################### Welcome tab with general app description #####################
    
    tabPanel("App introduction",
             fluidPage(
                 img(src = "header.png"),
                 column(8,
                        h1("Purpose"),
                        h4("This app is meant to explore the biology of 2 canine atrial fibrillation models.
                                    Three conditions (CTL; Control , ATP; Atrial tachypacing,
                                    AVB; ATP+Ventricular bloc) are compared with high trhoughput sequencing,
                                    namely i-RNAseq and ii-miRNAseq.
                                    The 4 next pages allow querying tables with genes of interest,
                                    extracting lists of genes corresponding to multiple filters,
                                    visualisation with boxplots and pathway analysis for a list of genes."),
                        br(),br(),
                        h4("Author"),
                        h3("Francis Leblanc")
                        ),
                 column(4,"")
                 )
             ),
    
    ########################### Tab 2 allows query of 4 datasets by genes #####################
    
    tabPanel("Tables genes search",
             fluidPage(
                 wellPanel(
                     # Genes to be queryied in 4 datasets
                     textInput("genes",
                               span(style="color:darkred", strong("List gene names comma seperated with 1 space")), 
                               value = "TTN, DES, FHL1, SORBS2, KCNA5, LENG8, MIR494",
                               placeholder = "TTN, DES, FHL1, SORBS2, KCNA5, LENG8, MIR494"),
                     
                     # customizable table's columns output
                     checkboxGroupInput("show_cols",
                                        "Columns to display",
                                        inline = T,
                                        colnames(all_res)[c(2:9,11,13:17)], selected = colnames(all_res)[2:9]),
                     
                     # Columns abreviations details
                     h5("*L2FC ; log2 fold change transformed normalized reads count,  ",
                     br(),
                     "*hsa.h ; homo sapiens homolog,")),
                 
                 # Tables
                 h3(strong("mRNA")),
                 DT::dataTableOutput("mRNA.tab"),
                 
                 h3(strong("miRNA")),
                 DT::dataTableOutput("miRNA.tab")
                 )
             ),
    
    
    ####################### Tab 3 allows filtering by variables to get corresponding genes #####
    
    tabPanel("Genes search by variables",
             fluidPage(
                 
                 wellPanel(
                     # Datasets selectiong for filtering 
                     checkboxGroupInput("dataset",
                                        "Dataset to plot",
                                        levels(all_res2$Dataset),
                                        selected = levels(all_res2$Dataset)[1:2],
                                        inline = T )),
                 wellPanel(
                     # Variables as filtrable histograms
                     h2("Click and drag on histograms to set filters for genes listed at the bottom"),
                     h4("double click to reset a filter"),
                     lapply(names(d), function(nm) plotlyOutput(nm, height = 200, width = "49%", inline = TRUE))),
                 
                 wellPanel(
                     # Show the actual ranges of filters 
                     h3("Ranges of current filters"),htmlOutput("ranges")),
                 
                 wellPanel(
                     # Genes corresponding to filters
                     h3("Genes that correspond to current filters"),
                     h5(strong("You may copy and paste that list to the pathway page")),
                     wellPanel(span(style="color:darkred", strong(textOutput("genes"))))
                     )
                 )
             ),
    
    
    ####################### Tab 4 Visualization of genes in 4 datasets with boxplots #########
    
    tabPanel("Boxplots",
             fluidPage(
                 # Genes input for Boxplots 
                 wellPanel(h3("Boxplot your genes of interest"),
                     textInput("genes_box",
                               span(style="color:darkred", strong("List gene names comma seperated with 1 space")),
                               value = "TTN, DES, FHL1, SORBS2, KCNA5, LENG8, MIR494",
                               placeholder = "TTN, DES, FHL1, SORBS2, KCNA5, LENG8, MIR494"))),
             fluidPage(
                 # Boxplots 
                 h4(strong("All genes are not present in each datasets")),
                 plotOutput("genes_box_mRNA"),
                 plotOutput("genes_box_miRNA")
                 )
             ),
    
    ####################### Tab 5 Run pathway analysis on genes of interest ##################
    
    tabPanel("Pathways",
             fluidPage(
                 # Genes input for pathway analysis
                 wellPanel(
                     # Datasets selectiong for filtering 
                     checkboxGroupInput("genesets",
                                        "Genesets to query",
                                        dbs,
                                        selected = dbs[2:4],
                                        inline = T )),
                 wellPanel(h3("Search pathways for a list of genes ",
                              span(style="color:darkred", tags$i("(this may take a minute)"))),
                           textInput("pathway",
                                     span(style="color:darkred", strong("List gene names comma seperated with 1 space")),
                                     value = "TTN, DES, FHL1, SORBS2, KCNA5, LENG8, MIR494",
                                     placeholder = "TTN, DES, FHL1, SORBS2, KCNA5, LENG8, MIR494"))),
             
             fluidPage(
                 # Pathway analysis output as table
                 h5("Databases queried; C1, C2.CP.BIOCARTA, C2.CP.KEGG, C2.CP.REACTOME, C3.MIR, C3.TFT, C5.BP, C5.CC, C5.MF, H. see"
                    ,tags$a(href="https://www.gsea-msigdb.org/gsea/msigdb/collections.jsp",
                            "https://www.gsea-msigdb.org/gsea/msigdb/collections.jsp"), "for description"),
                 DT::dataTableOutput("pathways.t"),
                 
                 # Pathway analysis output as PCA
                 br(),br(),
                 h4(strong("PCA shows pathways with overlaping genes closer together (fdr < 0.05)")),
                 h5("Hover to see the name of this pathway, click and drag to zoom and double click to reset"),
                 h5(em("multiple pathways may overlap with different fdr values if the same
                    genes are found within them but the number of genes in the pathway differ")),
                 br(),
                 span(style="color:darkred", h2(strong(textOutput("empty")))),
                 plotlyOutput("pathways.a", height = "500px"),
                 br(),br(),
                 
                 # Top 50 Pathway analysis output as dotplot
                 plotOutput("pathway.d", height = "800px")
             )
    )
)


######################################################## server ################################################################

server <- function(input, output, session) {
    
    ############### Tables tab; create 2 sortable tables reactive to input genes ################
    
    lapply(levels(all_res$Dataset), function(i) {
        output[[paste0(i,".tab")]] <- DT::renderDataTable({
            
        # make a usable vector from input string
        x <- unlist(strsplit(input$genes,", ")) 
        # keep only p-value columns to color red significant values
        y <- input$show_cols[which(input$show_cols %in% colnames(all_res)[pval.cols])]
        # cols to round
        z <- input$show_cols[which(input$show_cols %in% colnames(all_res)[c(pval.cols,L2FC.cols)])]
        # table wraper function for output
        DT::datatable(all_res[all_res$Gene %in% x & # keep only lines for genes in input
                                  all_res$Dataset == i,c("Gene","description",input$show_cols)], # keep only input columns (checked)
                      filter = list(position = 'bottom', clear = FALSE, plain = TRUE), # add filter at bottom of table
                      class = "compact", # tight output table to fit page
                      rownames = F, # remove line numbers
                      options = list(pageLength = 5,
                                     columnDefs = list(list(width = '10px',
                                                            className = 'dt-center', # center text in columns
                                                            targets = "_all")),
                                     # resize font 
                                     initComplete = JS( 
                                         "function(settings, json) {",
                                         "$(this.api().table().container()).css({'font-size': '80%'});",
                                         "}"))) %>% 
            # color red significant p-values
            formatStyle(columns =  y,
                        color = styleInterval(0.01,c("red", "black"))) 
            # formatRound(columns=z, digits=3)
    })
    })
    

    ############## Crossfilters tab; output gene list corresponding to filters ################
    
    #### Adapted following crossfilter code to include corresponding genes output
    #### https://rdrr.io/cran/plotly/src/inst/examples/shiny/crossfilter/app.R
    
    #  Make "d" a reactive df to filter dataset from checkbox
    makeReactiveBinding("d")
    newData <- reactive({
        
        input$dataset
        isolate({
            d <- subset(all_res2, Dataset %in% input$dataset, select = c(pval.cols,L2FC.cols))
        })
    })
    
    # These reactive values track the set of active brushes 
    # Each reactive value corresponds to a different variable 
    brush_ranges <- reactiveValues()
    
    # Filter the dataset based on every active brush range except for one (var)
    d_filter <- function(d, var = "mlog10CTLvsAVBpadj") {
        for (nm in setdiff(names(d), var)) {
            rng <- brush_ranges[[nm]]
            if (is.null(rng)) next
            d <- filter(d, between(d[[nm]], min(rng), max(rng)))
        }
        d
    }
    
    # Implement same render logic for each variable
    observeEvent(input$dataset, {
        # Update "d" 
        d <- newData()
        
        lapply(names(d), function(nm) {
        
            # Calculate counts per bins   
            counts <- d[[nm]] %>%
                bin_fixed(bins = 150) %>%
                compute_stat(d[[nm]]) %>%
                filter(!is.na(xmin_)) %>%
                mutate(xmid = (xmin_ + xmax_) / 2)
            
            # Render filtrable histograms for each variables
            output[[nm]] <- renderPlotly({
                
                plot_ly(counts, source = nm, marker = list(color = 'darkred')) %>%
                    add_bars(x = ~xmid, y = ~count_) %>%
                    layout(
                        plot_bgcolor='transparent', paper_bgcolor='transparent', 
                        dragmode = "select", 
                        selectdirection = "h",
                        xaxis = list(
                            title = nm,
                            range = range(d[[nm]], na.rm = TRUE)
                            ),
                        yaxis = list(title = "")
                        )
                })
            
            observeEvent(event_data("plotly_brushing", source = nm), ignoreNULL = FALSE, {
                
                # inform the world about the new brush range
                brush_ranges[[nm]] <- event_data("plotly_brushing", source = nm)$x
                
                # update the bar heights of every view 
                for (var in names(d)) {
                    
                    # views respect every brush except for their own 
                    d_filtered <- d_filter(d, var)
                        
                    # bin the filtered data based on the global binning definition
                    counts_filter <- d[[var]] %>%
                        bin_fixed(bins = 150) %>%
                        compute_stat(d_filtered[[var]]) %>%
                        filter(!is.na(xmin_)) %>%
                        mutate(xmid = (xmin_ + xmax_) / 2)
                    
                    # finally, update the bar heights
                    plotlyProxy(var, session) %>%
                        plotlyProxyInvoke("restyle", "y", list(counts_filter$count_), 0)
                }
                
                # Show user the current applied filters
                output$ranges <- renderText({
                    l <- as.list(as.data.frame(lapply(d_filtered,range,na.rm=T)))
                    l <- lapply(l, round, 2)
                    HTML(paste0("<B>",names(l),"</B>"," ;( min, max ) ;",l[names(l)],"<br/>"))
                    })
                
                # Show user the matching genes to current applied filters
                output$genes <- renderText({
                    
                    l <- as.list(as.data.frame(lapply(d_filtered,range,na.rm=T)))
                        
                    t <- vector(mode = "list", length = length(l))
                    names(t) <- names(l)
                    
                    # get genes matching each variable's filter
                    for (i in names(l)){
                        df2 <- all_res2[which(all_res2$Dataset %in% input$dataset),]
                        t[[i]] <- unlist(strsplit(df2[which(df2[,i] >= min(l[[i]]) & df2[,i] <= max(l[[i]])),"Gene"],";"))
                    }
                    
                    # keep only genes intersecting all filters
                    toString(paste(Reduce(intersect, t), sep=","))
                    })
                })
            })
        })
    
    ############## Boxplot tab; define 2 DF for 2 datasets to allow plotting for each ################
    lapply(levels(all_res2$Dataset), function(i) {
        # boxplot output for the 4 independent datasets
        output[[paste0("genes_box_",i)]] <- renderPlot({
            
            # keeping 1 dataset
            df <- all_res2[all_res2$Dataset %in% i,]
            
            # keep line of input genes
            genes <- unlist(strsplit(input$genes_box,", "))
            
            # gather expression levels for each samples
            df.box <- data.frame(t(df[match(genes,df$Gene),c((ncol(df)-17):ncol(df))])[,1:length(genes)],
                                 condition = c(rep("AVB",6),rep("ATP",6),rep("CTL",6)))
            
            df.box$samples <- colnames(df)[(ncol(df)-17):ncol(df)]
            colnames(df.box)[1:length(genes)] <- genes
            
            # melt for condition bining
            df.box.m <- melt(df.box)

            ggplot(df.box.m, aes(x = variable, y = value, fill = condition)) +
                geom_boxplot(alpha = .2, outlier.size = 0) +
                geom_point(aes(fill= condition), shape =21, size = 3, position = position_jitterdodge()) +
                ylab("log2 normalized expression") +
                xlab("Genes") +
                scale_fill_manual(values = c("red","darkblue","green"))+
                scale_colour_manual(values = c("darkblue","red","green"))+
                ggtitle(paste(i,"expression")) +
                theme_minimal() +
                theme(axis.text.x=element_text(angle=45, hjust=1))
        })
    })

    
    ############## Pathways tab; search pathways databases for overlaping genes ################
    # PCA render
    output$pathways.a <- renderPlotly({
        # input genes
        path.genes <- unlist(strsplit(input$pathway,", "))
        
        # input pathways
        genesets <- genesets[grep(paste(input$genesets, collapse = "|"), names(genesets))]
        
        # hypergeometric test for geneset enrichment 
        GSEA <- hypeR(path.genes, genesets ,fdr = 0.05, test = "hypergeometric", plotting =F)
        # GSEA <- hypeR(path.genes, genesets ,fdr_cutoff = 0.05, test = "hypergeometric", do_plots=F)
        GSEA_df <- GSEA$as.data.frame()
        
        # render table of pathways results
        output$pathways.t <- DT::renderDataTable({
            cols <- colnames(GSEA_df)[which(colnames(GSEA_df) %in%
                                                c("label","pval","fdr","overlap","genes.overlap","gset.size","geneset","hits"))]
            DT::datatable(GSEA_df[,cols],
                          filter = list(position = 'bottom', clear = FALSE, plain = TRUE),
                          class = "compact",
                          rownames = F,
                          options = list(pageLength = 5,
                                         columnDefs = list(list(width = '10px',
                                                                className = 'dt-center', 
                                                                targets = "_all")),
                                         initComplete = JS(
                                             "function(settings, json) {",
                                             "$(this.api().table().container()).css({'font-size': '80%'});",
                                             "}")
                          )
            ) 
        })
        
        # return message and NULL values if DF is empty
        if (nrow(GSEA_df) == 0){
            output$pathway.d <- NULL
            output$empty <- renderText("Nothing significant has been found")
            return(NULL)
        }
        else{
            output$empty <- NULL
            
            # render top 50 pathways as dot plot
            # get pathway names with corresponding database
            GSEA.l <- GSEA[["data"]][["hits"]]
            names(GSEA.l) <- GSEA[["data"]][["label"]]
            
            for (i in 1:length(GSEA.l)){
                GSEA.l[[i]] <- strsplit(GSEA.l[[i]],",")
            }
            
            # create a matrix with our genes in rows and pathways as columns with 0 and 1 for occurences
            df <- data.frame(matrix(ncol = length(GSEA.l), nrow = length(path.genes)))
            colnames(df) <- names(GSEA.l)
            row.names(df) <- path.genes
            df[,] <- 0
            for (i in 1:ncol(df)){
                for (j in 1:nrow(df)){
                    ifelse(row.names(df)[j] %in% GSEA.l[[i]][[1]], df[j,i]<-1, df[j,i]<-0)
                }
            }
            
            # run PCA on matrix
            pca <- prcomp(t(df))
            
            GSEA_df[,(ncol(GSEA_df)+1):(ncol(GSEA_df)+2)] <- pca$x[,1:2]
            colnames(GSEA_df)[(ncol(GSEA_df)-1):ncol(GSEA_df)] <- colnames(pca$x[,1:2])
            
            output$pathway.d <- renderPlot({
                
                # order by fdr values
                GSEA_df.o <- GSEA_df[order(GSEA_df$fdr),]
                GSEA_df.o$label <- factor(GSEA_df.o$label, levels = GSEA_df.o$label[order(GSEA_df.o$fdr, decreasing = T)])
                colnames(GSEA_df.o) <- gsub("genes.", "", colnames(GSEA_df.o))
    
                ggplot(GSEA_df.o[1:50,], aes(x = -log10(fdr), y = label, fill = -log10(fdr))) +
                    scale_fill_gradient(low = "darkblue", high = "red") +
                    geom_point(shape= 21, aes(size = overlap)) +
                    ggtitle("Top 50 pathways") +
                    theme_minimal()
            })
            
            
            # render PCA of pathways results to parent reactive function
            GSEA_df$mlog10.fdr <- -log10(GSEA_df$fdr)
            p <- plot_ly(data = GSEA_df, x = ~PC1, y = ~PC2,  text= ~label, type = 'scatter', mode = 'markers',
                    marker = list(color=~mlog10.fdr,
                                  size=~mlog10.fdr*5,
                                  opacity = 0.8,
                                  colorscale = 'Bluered',
                                  colorbar=list(title='-log10(fdr)'),
                                  line = list(color = 'black',width = 2)))
            
            p %>% layout(title = 'PCA of overlaping genes found in pathways', showlegend = F,
                         annotations = 
                             list(x = 1, y = -0, text = "Color and size reflect -log10(fdr)", 
                                  showarrow = F, xref='paper', yref='paper', 
                                  xanchor='right', yanchor='auto', xshift=0, yshift=0,
                                  font=list(size=15, color="darkred")))
        }
        })
    
    }

shinyApp(ui, server)